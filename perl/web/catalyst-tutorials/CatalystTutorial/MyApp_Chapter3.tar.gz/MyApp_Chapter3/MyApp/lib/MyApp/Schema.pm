package MyApp::Schema;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;


# Created by DBIx::Class::Schema::Loader v0.05002 @ 2010-02-17 15:29:27
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:1k0GfzGX/McG/tJ0TnITjw


# You can replace this text with custom content, and it will be preserved on regeneration
1;
