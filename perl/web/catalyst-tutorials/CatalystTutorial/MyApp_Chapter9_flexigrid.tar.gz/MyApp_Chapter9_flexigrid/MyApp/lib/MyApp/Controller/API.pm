package MyApp::Controller::API;

use strict;
use warnings;
use parent 'Catalyst::Controller::REST';
use POSIX ();

__PACKAGE__->config(default => 'application/json');
__PACKAGE__->config->{map}{'application/vnd.ms-excel'} = 'SimpleExcel';

sub grid : Local ActionClass('REST') {}

sub grid_POST {
    my ($self, $c) = @_;

    my ($page, $search_by, $search_text, $rows, $sort_by, $sort_order) =
        @{ $c->req->params }{qw/page qtype query rp sortname sortorder/};

    s/\W*(\w+).*/$1/ for $sort_by, $sort_order, $search_by; # sql injections bad

    my %data;

    my $rs = $c->model('DB::Book')->search({}, {
        order_by => "$sort_by $sort_order",
    });

    $rs = $rs->search_literal("lower($search_by) LIKE ?", lc($search_text))
        if $search_by && $search_text;

    my $paged_rs = $rs->search({}, {
        page => $page,
        rows => $rows,
    });

    $data{total} = $rs->count;
    $data{page}  = $page;
    $data{rows}  = [
        map { +{
            id => $_->id,
            cell => [
                $_->id,
                $_->title,
                $_->rating,
                $_->author_list,
            ]
        } } $paged_rs->all
    ];

    $self->status_ok($c, entity => \%data);
}

sub book : Local ActionClass('REST') {
    my ($self, $c, $id) = @_;

    $c->stash(book => $c->model('DB::Book')->find($id));
}

sub book_DELETE {
    my ($self, $c, $id) = @_;

    $c->stash->{book}->delete;

    $self->status_ok($c, entity => { message => 'success' });
}

sub books : Local ActionClass('REST') {}

sub books_GET {
    my ($self, $c) = @_;

    my $rs = $c->model('DB::Book')->search({}, {
        order_by => ['title']
    });

    my @rows = map {
        [ $_->id, $_->title, $_->rating, $_->author_list ]
    } $rs->all;

    my $entity = {
        header => ['ID', 'Title', 'Rating', 'Authors'],
        rows => \@rows,
        filename => 'books-'.POSIX::strftime('%m-%d-%Y', localtime)
    };

    $self->status_ok(
        $c,
        entity => $entity
    );
}

1;
