package MyApp::Schema;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces(
    result_namespace => 'Result',
);


# Created by DBIx::Class::Schema::Loader v0.05002 @ 2010-02-17 16:11:03
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:j5kySHBu9x4UICiATq/+Uw


# You can replace this text with custom content, and it will be preserved on regeneration
1;
